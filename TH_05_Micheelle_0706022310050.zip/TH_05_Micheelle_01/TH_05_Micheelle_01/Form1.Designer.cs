﻿namespace TH_05_Micheelle_01
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_Details = new System.Windows.Forms.Label();
            this.lbl_NamaProduct = new System.Windows.Forms.Label();
            this.lbl_CategoryProduct = new System.Windows.Forms.Label();
            this.lbl_Harga = new System.Windows.Forms.Label();
            this.lbl_Stock = new System.Windows.Forms.Label();
            this.lbl_Category = new System.Windows.Forms.Label();
            this.lbl_NamaCategory = new System.Windows.Forms.Label();
            this.txbx_NamaProduct = new System.Windows.Forms.TextBox();
            this.txbx_HargaProduct = new System.Windows.Forms.TextBox();
            this.txbx_StockProduct = new System.Windows.Forms.TextBox();
            this.txbx_NamaCategory = new System.Windows.Forms.TextBox();
            this.cobox_CategoryProduct = new System.Windows.Forms.ComboBox();
            this.dataGridView_ProductAll = new System.Windows.Forms.DataGridView();
            this.btn_AddProduct = new System.Windows.Forms.Button();
            this.btn_EditProduct = new System.Windows.Forms.Button();
            this.btn_RemoveProduct = new System.Windows.Forms.Button();
            this.btn_AddCategory = new System.Windows.Forms.Button();
            this.btn_RemoveCategory = new System.Windows.Forms.Button();
            this.btn_All = new System.Windows.Forms.Button();
            this.btn_Filter = new System.Windows.Forms.Button();
            this.cobox_Filter = new System.Windows.Forms.ComboBox();
            this.dataGridView_Filter = new System.Windows.Forms.DataGridView();
            this.dataGridView_Category = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_ProductAll)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Filter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Category)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(39, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Product";
            // 
            // lbl_Details
            // 
            this.lbl_Details.AutoSize = true;
            this.lbl_Details.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Details.Location = new System.Drawing.Point(38, 481);
            this.lbl_Details.Name = "lbl_Details";
            this.lbl_Details.Size = new System.Drawing.Size(94, 29);
            this.lbl_Details.TabIndex = 1;
            this.lbl_Details.Text = "Details";
            // 
            // lbl_NamaProduct
            // 
            this.lbl_NamaProduct.AutoSize = true;
            this.lbl_NamaProduct.Location = new System.Drawing.Point(39, 530);
            this.lbl_NamaProduct.Name = "lbl_NamaProduct";
            this.lbl_NamaProduct.Size = new System.Drawing.Size(59, 20);
            this.lbl_NamaProduct.TabIndex = 2;
            this.lbl_NamaProduct.Text = "Nama :";
            // 
            // lbl_CategoryProduct
            // 
            this.lbl_CategoryProduct.AutoSize = true;
            this.lbl_CategoryProduct.Location = new System.Drawing.Point(17, 562);
            this.lbl_CategoryProduct.Name = "lbl_CategoryProduct";
            this.lbl_CategoryProduct.Size = new System.Drawing.Size(81, 20);
            this.lbl_CategoryProduct.TabIndex = 3;
            this.lbl_CategoryProduct.Text = "Category :";
            // 
            // lbl_Harga
            // 
            this.lbl_Harga.AutoSize = true;
            this.lbl_Harga.Location = new System.Drawing.Point(36, 596);
            this.lbl_Harga.Name = "lbl_Harga";
            this.lbl_Harga.Size = new System.Drawing.Size(61, 20);
            this.lbl_Harga.TabIndex = 4;
            this.lbl_Harga.Text = "Harga :";
            // 
            // lbl_Stock
            // 
            this.lbl_Stock.AutoSize = true;
            this.lbl_Stock.Location = new System.Drawing.Point(39, 628);
            this.lbl_Stock.Name = "lbl_Stock";
            this.lbl_Stock.Size = new System.Drawing.Size(58, 20);
            this.lbl_Stock.TabIndex = 5;
            this.lbl_Stock.Text = "Stock :";
            // 
            // lbl_Category
            // 
            this.lbl_Category.AutoSize = true;
            this.lbl_Category.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Category.Location = new System.Drawing.Point(592, 16);
            this.lbl_Category.Name = "lbl_Category";
            this.lbl_Category.Size = new System.Drawing.Size(118, 29);
            this.lbl_Category.TabIndex = 6;
            this.lbl_Category.Text = "Category";
            // 
            // lbl_NamaCategory
            // 
            this.lbl_NamaCategory.AutoSize = true;
            this.lbl_NamaCategory.Location = new System.Drawing.Point(593, 350);
            this.lbl_NamaCategory.Name = "lbl_NamaCategory";
            this.lbl_NamaCategory.Size = new System.Drawing.Size(59, 20);
            this.lbl_NamaCategory.TabIndex = 7;
            this.lbl_NamaCategory.Text = "Nama :";
            // 
            // txbx_NamaProduct
            // 
            this.txbx_NamaProduct.Location = new System.Drawing.Point(122, 527);
            this.txbx_NamaProduct.Name = "txbx_NamaProduct";
            this.txbx_NamaProduct.Size = new System.Drawing.Size(417, 26);
            this.txbx_NamaProduct.TabIndex = 8;
            // 
            // txbx_HargaProduct
            // 
            this.txbx_HargaProduct.Location = new System.Drawing.Point(122, 593);
            this.txbx_HargaProduct.Name = "txbx_HargaProduct";
            this.txbx_HargaProduct.Size = new System.Drawing.Size(146, 26);
            this.txbx_HargaProduct.TabIndex = 9;
            this.txbx_HargaProduct.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txbx_HargaProduct_KeyPress);
            // 
            // txbx_StockProduct
            // 
            this.txbx_StockProduct.Location = new System.Drawing.Point(122, 625);
            this.txbx_StockProduct.Name = "txbx_StockProduct";
            this.txbx_StockProduct.Size = new System.Drawing.Size(146, 26);
            this.txbx_StockProduct.TabIndex = 10;
            this.txbx_StockProduct.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txbx_HargaProduct_KeyPress);
            // 
            // txbx_NamaCategory
            // 
            this.txbx_NamaCategory.Location = new System.Drawing.Point(658, 347);
            this.txbx_NamaCategory.Name = "txbx_NamaCategory";
            this.txbx_NamaCategory.Size = new System.Drawing.Size(228, 26);
            this.txbx_NamaCategory.TabIndex = 11;
            // 
            // cobox_CategoryProduct
            // 
            this.cobox_CategoryProduct.FormattingEnabled = true;
            this.cobox_CategoryProduct.Items.AddRange(new object[] {
            "Jas",
            "T-Shirt",
            "Rok",
            "Celana",
            "Cawat"});
            this.cobox_CategoryProduct.Location = new System.Drawing.Point(122, 559);
            this.cobox_CategoryProduct.Name = "cobox_CategoryProduct";
            this.cobox_CategoryProduct.Size = new System.Drawing.Size(146, 28);
            this.cobox_CategoryProduct.TabIndex = 12;
            // 
            // dataGridView_ProductAll
            // 
            this.dataGridView_ProductAll.AllowUserToAddRows = false;
            this.dataGridView_ProductAll.AllowUserToResizeColumns = false;
            this.dataGridView_ProductAll.AllowUserToResizeRows = false;
            this.dataGridView_ProductAll.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_ProductAll.CausesValidation = false;
            this.dataGridView_ProductAll.ColumnHeadersHeight = 34;
            this.dataGridView_ProductAll.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridView_ProductAll.Location = new System.Drawing.Point(43, 81);
            this.dataGridView_ProductAll.Name = "dataGridView_ProductAll";
            this.dataGridView_ProductAll.ReadOnly = true;
            this.dataGridView_ProductAll.RowHeadersVisible = false;
            this.dataGridView_ProductAll.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dataGridView_ProductAll.RowTemplate.Height = 20;
            this.dataGridView_ProductAll.RowTemplate.ReadOnly = true;
            this.dataGridView_ProductAll.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_ProductAll.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_ProductAll.Size = new System.Drawing.Size(496, 349);
            this.dataGridView_ProductAll.TabIndex = 13;
            this.dataGridView_ProductAll.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_ProductAll_CellClick);
            this.dataGridView_ProductAll.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_ProductAll_CellContentClick);
            this.dataGridView_ProductAll.Click += new System.EventHandler(this.dataGridView_ProductAll_Click);
            // 
            // btn_AddProduct
            // 
            this.btn_AddProduct.BackColor = System.Drawing.Color.Lime;
            this.btn_AddProduct.Location = new System.Drawing.Point(274, 578);
            this.btn_AddProduct.Name = "btn_AddProduct";
            this.btn_AddProduct.Size = new System.Drawing.Size(87, 62);
            this.btn_AddProduct.TabIndex = 15;
            this.btn_AddProduct.Text = "Add Product";
            this.btn_AddProduct.UseVisualStyleBackColor = false;
            this.btn_AddProduct.Click += new System.EventHandler(this.btn_AddProduct_Click);
            // 
            // btn_EditProduct
            // 
            this.btn_EditProduct.BackColor = System.Drawing.Color.Yellow;
            this.btn_EditProduct.Location = new System.Drawing.Point(363, 578);
            this.btn_EditProduct.Name = "btn_EditProduct";
            this.btn_EditProduct.Size = new System.Drawing.Size(87, 61);
            this.btn_EditProduct.TabIndex = 16;
            this.btn_EditProduct.Text = "Edit Product";
            this.btn_EditProduct.UseVisualStyleBackColor = false;
            this.btn_EditProduct.Click += new System.EventHandler(this.btn_EditProduct_Click);
            // 
            // btn_RemoveProduct
            // 
            this.btn_RemoveProduct.BackColor = System.Drawing.Color.Red;
            this.btn_RemoveProduct.Location = new System.Drawing.Point(452, 578);
            this.btn_RemoveProduct.Name = "btn_RemoveProduct";
            this.btn_RemoveProduct.Size = new System.Drawing.Size(87, 63);
            this.btn_RemoveProduct.TabIndex = 17;
            this.btn_RemoveProduct.Text = "Remove Product";
            this.btn_RemoveProduct.UseVisualStyleBackColor = false;
            this.btn_RemoveProduct.Click += new System.EventHandler(this.btn_RemoveProduct_Click);
            // 
            // btn_AddCategory
            // 
            this.btn_AddCategory.BackColor = System.Drawing.Color.Lime;
            this.btn_AddCategory.Location = new System.Drawing.Point(698, 388);
            this.btn_AddCategory.Name = "btn_AddCategory";
            this.btn_AddCategory.Size = new System.Drawing.Size(90, 62);
            this.btn_AddCategory.TabIndex = 18;
            this.btn_AddCategory.Text = "Add Category";
            this.btn_AddCategory.UseVisualStyleBackColor = false;
            this.btn_AddCategory.Click += new System.EventHandler(this.btn_AddCategory_Click);
            // 
            // btn_RemoveCategory
            // 
            this.btn_RemoveCategory.BackColor = System.Drawing.Color.Red;
            this.btn_RemoveCategory.Location = new System.Drawing.Point(794, 388);
            this.btn_RemoveCategory.Name = "btn_RemoveCategory";
            this.btn_RemoveCategory.Size = new System.Drawing.Size(90, 62);
            this.btn_RemoveCategory.TabIndex = 19;
            this.btn_RemoveCategory.Text = "Remove Category";
            this.btn_RemoveCategory.UseVisualStyleBackColor = false;
            this.btn_RemoveCategory.Click += new System.EventHandler(this.btn_RemoveCategory_Click);
            // 
            // btn_All
            // 
            this.btn_All.Location = new System.Drawing.Point(266, 41);
            this.btn_All.Name = "btn_All";
            this.btn_All.Size = new System.Drawing.Size(48, 34);
            this.btn_All.TabIndex = 20;
            this.btn_All.Text = "All";
            this.btn_All.UseVisualStyleBackColor = true;
            this.btn_All.Click += new System.EventHandler(this.btn_All_Click);
            // 
            // btn_Filter
            // 
            this.btn_Filter.Location = new System.Drawing.Point(320, 41);
            this.btn_Filter.Name = "btn_Filter";
            this.btn_Filter.Size = new System.Drawing.Size(69, 34);
            this.btn_Filter.TabIndex = 21;
            this.btn_Filter.Text = "Filter:";
            this.btn_Filter.UseVisualStyleBackColor = true;
            this.btn_Filter.Click += new System.EventHandler(this.btn_Filter_Click);
            // 
            // cobox_Filter
            // 
            this.cobox_Filter.Enabled = false;
            this.cobox_Filter.FormattingEnabled = true;
            this.cobox_Filter.Items.AddRange(new object[] {
            "Jas",
            "T-Shirt",
            "Rok",
            "Celana",
            "Cawat"});
            this.cobox_Filter.Location = new System.Drawing.Point(395, 41);
            this.cobox_Filter.Name = "cobox_Filter";
            this.cobox_Filter.Size = new System.Drawing.Size(144, 28);
            this.cobox_Filter.TabIndex = 22;
            this.cobox_Filter.SelectedIndexChanged += new System.EventHandler(this.cobox_Filter_SelectedIndexChanged);
            // 
            // dataGridView_Filter
            // 
            this.dataGridView_Filter.AllowUserToAddRows = false;
            this.dataGridView_Filter.AllowUserToResizeColumns = false;
            this.dataGridView_Filter.AllowUserToResizeRows = false;
            this.dataGridView_Filter.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_Filter.CausesValidation = false;
            this.dataGridView_Filter.ColumnHeadersHeight = 34;
            this.dataGridView_Filter.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridView_Filter.Location = new System.Drawing.Point(43, 81);
            this.dataGridView_Filter.Name = "dataGridView_Filter";
            this.dataGridView_Filter.ReadOnly = true;
            this.dataGridView_Filter.RowHeadersVisible = false;
            this.dataGridView_Filter.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dataGridView_Filter.RowTemplate.Height = 20;
            this.dataGridView_Filter.RowTemplate.ReadOnly = true;
            this.dataGridView_Filter.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_Filter.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_Filter.Size = new System.Drawing.Size(496, 349);
            this.dataGridView_Filter.TabIndex = 23;
            this.dataGridView_Filter.Visible = false;
            this.dataGridView_Filter.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick_1);
            this.dataGridView_Filter.Click += new System.EventHandler(this.dataGridView_ProductAll_Click);
            // 
            // dataGridView_Category
            // 
            this.dataGridView_Category.AllowUserToAddRows = false;
            this.dataGridView_Category.AllowUserToResizeColumns = false;
            this.dataGridView_Category.AllowUserToResizeRows = false;
            this.dataGridView_Category.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_Category.CausesValidation = false;
            this.dataGridView_Category.ColumnHeadersHeight = 34;
            this.dataGridView_Category.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridView_Category.Location = new System.Drawing.Point(597, 81);
            this.dataGridView_Category.MultiSelect = false;
            this.dataGridView_Category.Name = "dataGridView_Category";
            this.dataGridView_Category.ReadOnly = true;
            this.dataGridView_Category.RowHeadersVisible = false;
            this.dataGridView_Category.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dataGridView_Category.RowTemplate.Height = 20;
            this.dataGridView_Category.RowTemplate.ReadOnly = true;
            this.dataGridView_Category.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_Category.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_Category.Size = new System.Drawing.Size(289, 235);
            this.dataGridView_Category.TabIndex = 24;
            this.dataGridView_Category.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_Category_CellClick_1);
            this.dataGridView_Category.Click += new System.EventHandler(this.dataGridView_ProductAll_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.LightSalmon;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(919, 739);
            this.Controls.Add(this.cobox_Filter);
            this.Controls.Add(this.btn_Filter);
            this.Controls.Add(this.btn_All);
            this.Controls.Add(this.btn_RemoveCategory);
            this.Controls.Add(this.btn_AddCategory);
            this.Controls.Add(this.btn_RemoveProduct);
            this.Controls.Add(this.btn_EditProduct);
            this.Controls.Add(this.btn_AddProduct);
            this.Controls.Add(this.dataGridView_ProductAll);
            this.Controls.Add(this.cobox_CategoryProduct);
            this.Controls.Add(this.txbx_NamaCategory);
            this.Controls.Add(this.txbx_StockProduct);
            this.Controls.Add(this.txbx_HargaProduct);
            this.Controls.Add(this.txbx_NamaProduct);
            this.Controls.Add(this.lbl_NamaCategory);
            this.Controls.Add(this.lbl_Category);
            this.Controls.Add(this.lbl_Stock);
            this.Controls.Add(this.lbl_Harga);
            this.Controls.Add(this.lbl_CategoryProduct);
            this.Controls.Add(this.lbl_NamaProduct);
            this.Controls.Add(this.lbl_Details);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView_Filter);
            this.Controls.Add(this.dataGridView_Category);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Blink Shop";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_ProductAll)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Filter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Category)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_Details;
        private System.Windows.Forms.Label lbl_NamaProduct;
        private System.Windows.Forms.Label lbl_CategoryProduct;
        private System.Windows.Forms.Label lbl_Harga;
        private System.Windows.Forms.Label lbl_Stock;
        private System.Windows.Forms.Label lbl_Category;
        private System.Windows.Forms.Label lbl_NamaCategory;
        private System.Windows.Forms.TextBox txbx_NamaProduct;
        private System.Windows.Forms.TextBox txbx_HargaProduct;
        private System.Windows.Forms.TextBox txbx_StockProduct;
        private System.Windows.Forms.TextBox txbx_NamaCategory;
        private System.Windows.Forms.ComboBox cobox_CategoryProduct;
        private System.Windows.Forms.DataGridView dataGridView_ProductAll;
        private System.Windows.Forms.Button btn_AddProduct;
        private System.Windows.Forms.Button btn_EditProduct;
        private System.Windows.Forms.Button btn_RemoveProduct;
        private System.Windows.Forms.Button btn_AddCategory;
        private System.Windows.Forms.Button btn_RemoveCategory;
        private System.Windows.Forms.Button btn_All;
        private System.Windows.Forms.Button btn_Filter;
        private System.Windows.Forms.ComboBox cobox_Filter;
        private System.Windows.Forms.DataGridView dataGridView_Filter;
        private System.Windows.Forms.DataGridView dataGridView_Category;
    }
}

