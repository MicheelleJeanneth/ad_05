﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH_05_Micheelle_01
{
    public partial class Form1 : Form
    {
        DataTable dtProdukSimpan = new DataTable();
        DataTable dtProdukTampil = new DataTable();
        DataTable dtCategory = new DataTable();

        bool cek = false;
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            string[,] Product = new string[8, 5]
                                {{"J001","Jas Hitam","100000", "10", "C1"}, {"T001","T-Shirt Black Pink","70000", "20", "C2"},
                                {"T002","T-Shirt Obsessive","75000", "16", "C2"}, {"R001","Rok Mini","82000", "26", "C3"},
                                {"J002","Jeans Biru","90000", "5", "C4"}, {"C001","Celana Pendek Coklat","60000", "11", "C4"},
                                {"C002","Cawat Blink-Blink","1000000", "1", "C5"}, {"R002","Rocca Shirt","50000", "8", "C2"}};
            dtProdukSimpan.Columns.Add("ID Product");
            dtProdukSimpan.Columns.Add("Nama Product");
            dtProdukSimpan.Columns.Add("Harga");
            dtProdukSimpan.Columns.Add("Stock");
            dtProdukSimpan.Columns.Add("ID Category");
            for (int i = 0; i < 8; i++)
            {
                dtProdukSimpan.Rows.Add(Product[i, 0], Product[i, 1], Product[i, 2], Product[i, 3], Product[i, 4]);
            }
            dataGridView_ProductAll.DataSource = dtProdukSimpan;
            dataGridView_ProductAll.Columns[0].Width = 20;
            dataGridView_ProductAll.Columns[1].Width = 50;
            dataGridView_ProductAll.Columns[2].Width = 20;
            dataGridView_ProductAll.Columns[3].Width = 20;
            dataGridView_ProductAll.Columns[4].Width = 50;

            string[,] Category = new string[5, 2]
                                 {{"C1","Jas"}, {"C2","T-Shirt"}, {"C3","Rok"},
                                 {"C4","Celana"}, {"C5","Cawat"}};
            dtCategory.Columns.Add("ID Catgory");
            dtCategory.Columns.Add("Nama Category");
            for (int i = 0; i < 5; i++)
            {
                dtCategory.Rows.Add(Category[i, 0], Category[i, 1]);
            }
            dataGridView_Category.DataSource = dtCategory;
            dataGridView_Category.Columns[0].Width = 80;
            dataGridView_Category.Columns[1].Width = 80;
            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                dataGridView_Category.Rows[i].Height = 20;
            }

            dataGridView_ProductAll.ClearSelection();
            dataGridView_Category.ClearSelection();

            dtProdukTampil.Columns.Add("ID Product");
            dtProdukTampil.Columns.Add("Nama Product");
            dtProdukTampil.Columns.Add("Harga");
            dtProdukTampil.Columns.Add("Stock");
            dtProdukTampil.Columns.Add("ID Category");
            dataGridView_Filter.DataSource = dtProdukTampil;
        }

        private void btn_AddCategory_Click(object sender, EventArgs e)
        {
            if (txbx_NamaCategory.Text == "")
            {
                MessageBox.Show("Masukkan Nama Kategory Terlebih Dahulu");
            }
            else
            {
                bool sama = false;
                int count = dtCategory.Rows.Count - 1;
                string a = dtCategory.Rows[count][0].ToString().Substring(1, 1);
                int b = Convert.ToInt32(a) + 1;

                string category = "C" + b.ToString();
                
                for (int i = 0; i < dtCategory.Rows.Count; i++)
                {
                    if (dtCategory.Rows[i][1].ToString() == txbx_NamaCategory.Text)
                    {
                        sama = true;
                        break;
                    }
                    else
                    {
                        sama = false;
                    }
                }
                if (sama == true)
                {
                    MessageBox.Show("Category Sudah Ada");
                }
                else if (sama == false)
                {
                    if (dataGridView_Filter.Visible == true)
                    {
                        dataGridView_Filter.Visible = false;
                        dataGridView_ProductAll.Visible = true;
                    }
                    cobox_Filter.Text = "";
                    dtCategory.Rows.Add(category, txbx_NamaCategory.Text);
                    cobox_Filter.Items.Add(txbx_NamaCategory.Text);
                    cobox_CategoryProduct.Items.Add(txbx_NamaCategory.Text);
                    txbx_NamaCategory.Text = "";
                    txbx_NamaProduct.Text = "";
                    cobox_CategoryProduct.Text = "";
                    txbx_HargaProduct.Text = "";
                    txbx_StockProduct.Text = "";
                    dataGridView_Filter.ClearSelection();
                    dataGridView_Category.ClearSelection();
                    dataGridView_ProductAll.ClearSelection();
                    cek = false;
                }
            }
        }

        private void btn_RemoveCategory_Click(object sender, EventArgs e)
        {
            if (cek == true)
            {
                if (dataGridView_Filter.Visible == true)
                {
                    dataGridView_Filter.Visible = false;
                    dataGridView_ProductAll.Visible = true;
                }

                string c = dataGridView_Category.CurrentRow.Cells[0].Value.ToString();
                for (int i = dtCategory.Rows.Count - 1; i > -1; i--)
                {
                    if (dtCategory.Rows[i][0].ToString() == c)
                    {
                        dtCategory.Rows[i].Delete();
                        cobox_Filter.Items.RemoveAt(i);
                        cobox_CategoryProduct.Items.RemoveAt(i);
                    }
                }
                for (int j = dtProdukSimpan.Rows.Count - 1; j > -1; j--)
                {
                    if (dtProdukSimpan.Rows[j][4].ToString() == c)
                    {
                        dtProdukSimpan.Rows[j].Delete();
                    }
                }
                dataGridView_ProductAll.ClearSelection();
                dataGridView_Category.ClearSelection();
                cek = false;
                txbx_NamaCategory.Text = "";
                cobox_Filter.Text = "";
                txbx_NamaProduct.Text = "";
                cobox_CategoryProduct.Text = "";
                txbx_HargaProduct.Text = "";
                txbx_StockProduct.Text = "";
            }
        }

        private void btn_AddProduct_Click(object sender, EventArgs e)
        {
            if (txbx_NamaProduct.Text == "" || txbx_HargaProduct.Text == "" || txbx_StockProduct.Text == "")
            {
                MessageBox.Show("Input Yang Lengkap Ya");
            }
            else if (cobox_CategoryProduct.SelectedIndex == -1)
            {
                MessageBox.Show("Pilih Category Dulu Boy");
            }
            else
            {
                if (dataGridView_Filter.Visible == true)
                {
                    dataGridView_Filter.Visible = false;
                    dataGridView_ProductAll.Visible = true;
                    cobox_Filter.Text = "";
                }
                string a = "";
                for (int i = 0; i < dtCategory.Rows.Count; i++)
                {
                    if (cobox_CategoryProduct.SelectedItem.ToString() == dtCategory.Rows[i][1].ToString())
                    {
                        a = dtCategory.Rows[i][0].ToString();
                    }
                }
                int index = 1;
                string b = txbx_NamaProduct.Text.ToString().Substring(0, 1).ToUpper();
                for (int i = dtProdukSimpan.Rows.Count - 1; i >= 0; i--)
                {
                    if (dtProdukSimpan.Rows[i][0].ToString().Substring(0, 1) == b)
                    {
                        index = Convert.ToInt32(dtProdukSimpan.Rows[i][0].ToString().Substring(1, 3)) + 1;
                        break;
                    }
                }
                if (index <= 9)
                {
                    dtProdukSimpan.Rows.Add((b + "00" + index), txbx_NamaProduct.Text, txbx_HargaProduct.Text, txbx_StockProduct.Text, a);
                }
                else if (index > 9)
                {
                    dtProdukSimpan.Rows.Add((b + "0" + index), txbx_NamaProduct.Text, txbx_HargaProduct.Text, txbx_StockProduct.Text, a);
                }
                else if (index > 99)
                {
                    dtProdukSimpan.Rows.Add((b + index), txbx_NamaProduct.Text, txbx_HargaProduct.Text, txbx_StockProduct.Text, a);
                }
                dataGridView_ProductAll.ClearSelection();
                txbx_NamaProduct.Text = "";
                cobox_CategoryProduct.Text = "";
                txbx_HargaProduct.Text = "";
                txbx_StockProduct.Text = "";
                dataGridView_Category.ClearSelection();
                cobox_Filter.Text = "";
                txbx_NamaCategory.Text = "";
                cek = false;
            }
        }

        private void dataGridView_ProductAll_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow dgvr = dataGridView_ProductAll.CurrentRow;
            txbx_NamaProduct.Text = dgvr.Cells[1].Value.ToString();
            txbx_HargaProduct.Text = dgvr.Cells[2].Value.ToString();
            txbx_StockProduct.Text = dgvr.Cells[3].Value.ToString();

            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                if (dgvr.Cells[4].Value.ToString() == dtCategory.Rows[i][0].ToString())
                {
                    cobox_CategoryProduct.Text = dtCategory.Rows[i][1].ToString();
                }
            }
        }

        private void btn_EditProduct_Click(object sender, EventArgs e)
        {
            if (cek == true)
            {
                if (txbx_NamaProduct.Text == "" || txbx_HargaProduct.Text == "" || txbx_StockProduct.Text == "")
                {
                    MessageBox.Show("Input Yang Lengkap Ya");
                }
                else if (cobox_CategoryProduct.SelectedIndex == -1)
                {
                    MessageBox.Show("Pilih Category Dulu Boy");
                    dataGridView_Filter.Visible = false;
                    dataGridView_ProductAll.Visible = true;
                }
                else
                {
                    string ce = "";
                    int index = 0;
                    if (dataGridView_Filter.Visible == true)
                    {
                        DataGridViewRow dgvr = dataGridView_Filter.CurrentRow;
                        ce = dgvr.Cells[0].Value.ToString();
                        dataGridView_Filter.Visible = false;
                        dataGridView_ProductAll.Visible = true;
                        for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
                        {
                            if (ce == dtProdukSimpan.Rows[i][0].ToString())
                            {
                                index = i; 
                                break;
                            }
                        }
                        cobox_Filter.Text = "";
                    }
                    else if (dataGridView_ProductAll.Visible == true)
                    {
                        DataGridViewRow dgvr = dataGridView_ProductAll.CurrentRow;
                        ce = dgvr.Cells[0].Value.ToString();
                        for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
                        {
                            if (ce == dtProdukSimpan.Rows[i][0].ToString())
                            {
                                index = i; 
                                break;
                            }
                        }
                    }

                    dtProdukSimpan.Rows[index][1] = txbx_NamaProduct.Text;
                    dtProdukSimpan.Rows[index][2] = txbx_HargaProduct.Text;
                    dtProdukSimpan.Rows[index][3] = txbx_StockProduct.Text;

                    for (int i = 0; i < dtCategory.Rows.Count; i++)
                    {
                        if (cobox_CategoryProduct.SelectedItem.ToString() == dtCategory.Rows[i][1].ToString())
                        {
                            dtProdukSimpan.Rows[index][4] = dtCategory.Rows[i][0];
                        }
                    }

                    if (txbx_StockProduct.Text == "0")
                    {
                        dtProdukSimpan.Rows.RemoveAt(index);
                    }
                }
                dataGridView_Category.ClearSelection();
                txbx_NamaCategory.Text = "";
                txbx_NamaProduct.Text = "";
                txbx_HargaProduct.Text = "";
                txbx_StockProduct.Text = "";
                cobox_CategoryProduct.Text = "";
                cobox_Filter.Text = "";
                cek = false;
                dataGridView_ProductAll.ClearSelection();
            }
            else
            {
                MessageBox.Show("Dipilih dlu");
            }
            if (dataGridView_Filter.Visible == true)
            {
                dataGridView_Filter.Visible = false;
                dataGridView_ProductAll.Visible = true;
            }
        }

        private void btn_RemoveProduct_Click(object sender, EventArgs e)
        {
            if (cek == true)
            {
                string ce = "";
                int index = 0;
                if (dataGridView_Filter.Visible == true)
                {
                    DataGridViewRow dgvr = dataGridView_Filter.CurrentRow;
                    ce = dgvr.Cells[0].Value.ToString();
                    dataGridView_Filter.Visible = false;
                    dataGridView_ProductAll.Visible = true;
                    for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
                    {
                        if (ce == dtProdukSimpan.Rows[i][0].ToString())
                        {
                            index = i; 
                            break;
                        }
                    }
                    cobox_Filter.Text = "";
                }
                else if (dataGridView_ProductAll.Visible == true)
                {
                    DataGridViewRow dgvr = dataGridView_ProductAll.CurrentRow;
                    ce = dgvr.Cells[0].Value.ToString();
                    for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
                    {
                        if (ce == dtProdukSimpan.Rows[i][0].ToString())
                        {
                            index = i;
                            break;
                        }
                    }
                }
                dtProdukSimpan.Rows.RemoveAt(index);
                dataGridView_Category.ClearSelection();
                txbx_NamaCategory.Text = "";
                txbx_NamaProduct.Text = "";
                txbx_HargaProduct.Text = "";
                txbx_StockProduct.Text = "";
                cobox_CategoryProduct.Text = "";
                cek = false;
                dataGridView_ProductAll.ClearSelection();
            }
            else
            {
                if (dataGridView_Filter.Visible == true)
                {
                    dataGridView_ProductAll.Visible = true;
                    dataGridView_Filter.Visible = false;
                }
                cobox_Filter.Text = "";
                dataGridView_Category.ClearSelection();
                txbx_NamaCategory.Text = "";
            }
        }

        private void btn_Filter_Click(object sender, EventArgs e)
        {
            cobox_Filter.Enabled = true;
            cobox_Filter.Items.Clear();

            foreach (DataGridViewRow row in dataGridView_Category.Rows)
            {
                cobox_Filter.Items.Add(row.Cells[1].Value.ToString());
            }
        }
        private void dataGridView_ProductAll_Click(object sender, EventArgs e)
        {
            cek = true;
        }
        private void cobox_Filter_SelectedIndexChanged(object sender, EventArgs e)
        {
            cek = false;
            txbx_NamaCategory.Text = "";
            txbx_NamaProduct.Text = "";
            txbx_HargaProduct.Text = "";
            txbx_StockProduct.Text = "";
            txbx_NamaCategory.Text = "";
            cobox_CategoryProduct.Text = "";
            dataGridView_ProductAll.ClearSelection();
            dataGridView_Category.ClearSelection();
            dataGridView_Filter.ClearSelection();
            dtProdukTampil.Clear();
            dataGridView_Filter.Visible = true;
            dataGridView_ProductAll.Visible = false;
            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                if (cobox_Filter.Text == dtCategory.Rows[i][1].ToString())
                {
                    for (int j = 0; j < dtProdukSimpan.Rows.Count; j++)
                    {
                        if (dtProdukSimpan.Rows[j][4] == dtCategory.Rows[i][0])
                        {
                            dtProdukTampil.Rows.Add(dtProdukSimpan.Rows[j][0], dtProdukSimpan.Rows[j][1], dtProdukSimpan.Rows[j][2], dtProdukSimpan.Rows[j][3], dtProdukSimpan.Rows[j][4]);
                        }
                    }
                }
            }
            dataGridView_Filter.ClearSelection();
        }

        private void txbx_HargaProduct_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back;
        }

        private void btn_All_Click(object sender, EventArgs e)
        {
            dataGridView_Filter.Visible = false;
            dataGridView_ProductAll.Visible = true;
            cobox_Filter.Enabled = false;
            cobox_Filter.Text = "";
            dataGridView_ProductAll.ClearSelection();
            dataGridView_Category.ClearSelection();
            txbx_NamaCategory.Text = "";
            txbx_NamaProduct.Text = "";
            cobox_CategoryProduct.Text = "";
            txbx_HargaProduct.Text = "";
            txbx_StockProduct.Text = "";
            cek = false;
        }

        private void dataGridView1_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow dgvr = dataGridView_Filter.CurrentRow;
            txbx_NamaProduct.Text = dgvr.Cells[1].Value.ToString();
            txbx_HargaProduct.Text = dgvr.Cells[2].Value.ToString();
            txbx_StockProduct.Text = dgvr.Cells[3].Value.ToString();

            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                if (dgvr.Cells[4].Value.ToString() == dtCategory.Rows[i][0].ToString())
                {
                    cobox_CategoryProduct.Text = dtCategory.Rows[i][1].ToString();
                }
            }
        }

        private void dataGridView_Category_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow dgvr = dataGridView_Category.CurrentRow;
            txbx_NamaCategory.Text = dgvr.Cells[1].Value.ToString();
        }

        private void dataGridView_ProductAll_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}